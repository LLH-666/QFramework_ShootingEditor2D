namespace FrameworkDesign
{
    public interface IUtility
    {
    }
}