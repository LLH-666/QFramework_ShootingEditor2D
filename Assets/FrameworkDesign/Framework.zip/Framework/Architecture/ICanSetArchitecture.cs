namespace FrameworkDesign
{
    public interface ICanSetArchitecture
    {
        void SetArchitecture(IArchitecture architecture);
    }
}